'''Create GUI for application'''
