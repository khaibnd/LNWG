'''Check consistency for each lot, from begin to the end:
    1. No change total num of lot in solution, in each observation
    2. No change part before and after each generatioh each each lot#
    3. No change 
'''